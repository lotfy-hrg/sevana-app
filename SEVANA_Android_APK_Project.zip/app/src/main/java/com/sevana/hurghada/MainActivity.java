package com.sevana.hurghada;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) {
                    return;
                }
                Uri[] results = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            });

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        root.setBackgroundColor(Color.parseColor("#091a2c"));
        root.setFitsSystemWindows(true);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));
        webView.setBackgroundColor(Color.parseColor("#091a2c"));
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView);
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() != null ? uri.getScheme().toLowerCase() : "";
                String host = uri.getHost() != null ? uri.getHost().toLowerCase() : "";

                if ("file".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }

                if ("tel".equals(scheme)
                        || "mailto".equals(scheme)
                        || "whatsapp".equals(scheme)
                        || "intent".equals(scheme)
                        || host.contains("wa.me")
                        || host.contains("whatsapp.com")
                        || "http".equals(scheme)
                        || "https".equals(scheme)) {
                    openExternalUri(uri);
                    return true;
                }

                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAndroidHelpers();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);

                try {
                    fileChooserLauncher.launch(Intent.createChooser(intent, "اختر ملفاً"));
                } catch (ActivityNotFoundException e) {
                    MainActivity.this.filePathCallback = null;
                    Toast.makeText(MainActivity.this, "تعذر فتح منتقي الملفات", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(
                    String url,
                    String userAgent,
                    String contentDisposition,
                    String mimetype,
                    long contentLength
            ) {
                String filename = URLUtil.guessFileName(url, contentDisposition, mimetype);
                if (url.startsWith("data:")) {
                    saveDataUrl(url, filename, mimetype);
                } else if (url.startsWith("blob:")) {
                    fetchBlobAndSave(url, filename, mimetype);
                } else {
                    openExternalUri(Uri.parse(url));
                }
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) {
                    webView.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void openExternalUri(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "لا يوجد تطبيق مناسب لفتح الرابط", Toast.LENGTH_SHORT).show();
        }
    }

    private void injectAndroidHelpers() {
        String js = "(function(){"
                + "if(window.__sevanaAndroidPatched) return;"
                + "window.__sevanaAndroidPatched = true;"
                + "window.print = function(){ if(window.AndroidBridge){ window.AndroidBridge.printPage(); } };"
                + "document.addEventListener('click', function(e){"
                + "  var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;"
                + "  if(!a || !a.href) return;"
                + "  var fname = a.getAttribute('download') || 'sevana_export';"
                + "  if(a.href.indexOf('blob:') === 0){"
                + "    e.preventDefault();"
                + "    fetch(a.href).then(function(r){ return r.blob(); }).then(function(b){"
                + "      var reader = new FileReader();"
                + "      reader.onloadend = function(){"
                + "        if(window.AndroidBridge){ window.AndroidBridge.saveDataUrl(reader.result, fname, b.type || 'application/octet-stream'); }"
                + "      };"
                + "      reader.readAsDataURL(b);"
                + "    });"
                + "  } else if(a.href.indexOf('data:') === 0){"
                + "    e.preventDefault();"
                + "    if(window.AndroidBridge){ window.AndroidBridge.saveDataUrl(a.href, fname, 'application/octet-stream'); }"
                + "  }"
                + "}, true);"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void fetchBlobAndSave(String blobUrl, String filename, String mimeType) {
        String safeUrl = blobUrl.replace("'", "\'");
        String safeName = filename.replace("'", "\'");
        String safeMime = (mimeType != null ? mimeType : "application/octet-stream").replace("'", "\'");
        String js = "fetch('" + safeUrl + "').then(function(r){ return r.blob(); }).then(function(b){"
                + "var reader = new FileReader();"
                + "reader.onloadend = function(){ AndroidBridge.saveDataUrl(reader.result, '" + safeName + "', b.type || '" + safeMime + "'); };"
                + "reader.readAsDataURL(b);"
                + "});";
        webView.evaluateJavascript(js, null);
    }

    private void saveDataUrl(String dataUrl, String filename, String mimeType) {
        try {
            int commaIdx = dataUrl.indexOf(',');
            if (commaIdx < 0) return;
            String header = dataUrl.substring(0, commaIdx);
            String payload = dataUrl.substring(commaIdx + 1);
            if ((mimeType == null || mimeType.isEmpty()) && header.contains(":") && header.contains(";")) {
                mimeType = header.substring(header.indexOf(':') + 1, header.indexOf(';'));
            }
            if (mimeType == null || mimeType.isEmpty()) {
                mimeType = "application/octet-stream";
            }
            byte[] data = Base64.decode(payload, Base64.DEFAULT);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri != null) {
                    try (OutputStream out = resolver.openOutputStream(uri)) {
                        if (out != null) {
                            out.write(data);
                        }
                    }
                }
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                File outFile = new File(dir, filename);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(data);
                }
            }

            runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, "تم حفظ الملف في التنزيلات: " + filename, Toast.LENGTH_LONG).show()
            );
        } catch (Exception e) {
            runOnUiThread(() ->
                    Toast.makeText(MainActivity.this, "تعذر حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show()
            );
        }
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void printPage() {
            runOnUiThread(() -> {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager != null) {
                    String jobName = "SEVANA_Document";
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
                    printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
                }
            });
        }

        @JavascriptInterface
        public void saveDataUrl(String dataUrl, String filename, String mimeType) {
            MainActivity.this.saveDataUrl(dataUrl, filename, mimeType);
        }
    }
}
