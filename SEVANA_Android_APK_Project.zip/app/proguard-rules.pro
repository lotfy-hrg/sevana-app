# Add project specific ProGuard rules here.
-keepclassmembers class com.sevana.hurghada.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
